import { Routes, Route, Navigate } from "react-router-dom";
import Layout from "./layout/Layout";
import ProtectedRoute from "./auth/ProtectedRoute"; // Naya Import

// Pages
import Dashboard from "./pages/Dashboard/Dashboard";
import Login from "./Authentication/Login";
import ManageUsers from "./pages/User_Management/ManageUsers";
import ReportsAnalytics from "./pages/Reports & Analytics/Reports";
import LocalNeeds from "./pages/LocalNeeds/LocalNeeds";
import PartTimeJobs from "./pages/Jobs/PartTimeJobs";
import FullTimeJobs from "./pages/Jobs/FullTimeJobs";
import Marketplace from "./pages/Marketplace/Marketplace";
import ShopManagement from "./pages/ShopManagement/ShopManagement";
import OwnerProfile from "./pages/ShopManagement/OwnerProfile";
import ShopDetail from "./pages/ShopManagement/ShopDetail";
import Credits from "./pages/Credits-Management/Credits";

function App() {
  return (
    <Routes>
  
      <Route path="/" element={<Navigate to="/login" replace />} />

    
      <Route path="/login" element={<Login />} />

    
      <Route 
        path="/" 
        element={
          <ProtectedRoute>
            <Layout />
          </ProtectedRoute>
        }
      >
        
        <Route index element={<Dashboard />} />
        <Route path="/usersmanagement" element={<ManageUsers />} />
        <Route path="/Reports" element={<ReportsAnalytics />} />
        <Route path="/needsManagement" element={<LocalNeeds />} />
        <Route path="/PartTimeJobs" element={<PartTimeJobs />} />
        <Route path="/FullTimeJobs" element={<FullTimeJobs />} />
        <Route path="/Marketplace" element={<Marketplace />} />
        <Route path="/ShopManagement" element={<ShopManagement />} />
        <Route path="/shop/:id" element={<ShopDetail />} />
        <Route path="/owner/profile/:id" element={<OwnerProfile />} />
        <Route path="/Credits" element={<Credits />} />
      </Route>

      <Route path="*" element={<Navigate to="/login" replace />} />
      
    </Routes>
  );
}

export default App;