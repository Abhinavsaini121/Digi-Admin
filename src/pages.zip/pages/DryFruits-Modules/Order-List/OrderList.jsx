import React from "react";

function OrderList() {
  const orders = [
    {
      id: "#ORD-1001",
      customer: "Rahul Sharma",
      product: "Mixed Dry Fruits",
      amount: "₹2000",
      status: "Pending",
      date: "12 Sep 2025",
    },
    {
      id: "#ORD-1002",
      customer: "Anjali Verma",
      product: "Almond Pack",
      amount: "₹1500",
      status: "Completed",
      date: "11 Sep 2025",
    },
    {
      id: "#ORD-1003",
      customer: "Amit Singh",
      product: "Cashew Premium",
      amount: "₹1800",
      status: "Cancelled",
      date: "10 Sep 2025",
    },
  ];

  const statusStyle = (status) => {
    switch (status) {
      case "Completed":
        return "bg-green-100 text-green-700";
      case "Pending":
        return "bg-orange-100 text-orange-700";
      case "Cancelled":
        return "bg-red-100 text-red-700";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  return (
    <div className="w-full min-h-screen bg-[#FFF8F4] px-4 md:px-8 py-6">
      <h1 className="text-2xl md:text-3xl font-bold text-gray-800 mb-6">
        Order List
      </h1>

      <div className="bg-white border border-orange-100 rounded-3xl shadow-sm overflow-hidden">

        {/* Table Header */}
        <div className="hidden md:grid grid-cols-6 gap-4 px-6 py-4 bg-orange-50 text-sm font-semibold text-gray-600">
          <span>Order ID</span>
          <span>Customer</span>
          <span>Product</span>
          <span>Amount</span>
          <span>Status</span>
          <span>Date</span>
        </div>

        {/* Orders */}
        {orders.map((order, index) => (
          <div
            key={index}
            className="grid grid-cols-1 md:grid-cols-6 gap-4 px-6 py-4 border-t border-orange-100 items-center"
          >
            <span className="font-medium text-gray-800">{order.id}</span>
            <span className="text-gray-600">{order.customer}</span>
            <span className="text-gray-600">{order.product}</span>
            <span className="font-semibold text-gray-700">
              {order.amount}
            </span>

            <span
              className={`inline-block w-fit px-3 py-1 rounded-full text-xs font-semibold ${statusStyle(
                order.status
              )}`}
            >
              {order.status}
            </span>

            <span className="text-gray-500 text-sm">{order.date}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default OrderList;
