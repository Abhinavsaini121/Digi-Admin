import React, { useState } from "react";
import { UploadCloud } from "lucide-react";

function AddProduct() {
  const [imagePreview, setImagePreview] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    price: "",
    ingredients: "",
    description: "",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImagePreview(URL.createObjectURL(file));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(formData);
  };

  return (
    <div className="w-full min-h-screen bg-[#FFF8F4] px-4 md:px-10 py-8">
      <h1 className="text-2xl md:text-3xl font-bold text-gray-800 mb-8">
        Add New Product
      </h1>

      <div className="max-w-4xl mx-auto bg-white rounded-3xl shadow-sm border border-orange-100 overflow-hidden">
        <div className="bg-gradient-to-br from-orange-50 to-[#FFF4EC] p-8 flex flex-col items-center">
          <div className="w-40 h-40 rounded-full bg-white border border-orange-200 flex items-center justify-center overflow-hidden">
            {imagePreview ? (
              <img src={imagePreview} className="w-full h-full object-cover" />
            ) : (
              <UploadCloud className="w-10 h-10 text-orange-400" />
            )}
          </div>

          <label className="mt-4 text-[#FE702E] font-medium cursor-pointer">
            Upload Product Image
            <input type="file" hidden onChange={handleImageUpload} />
          </label>
        </div>

        <form
          onSubmit={handleSubmit}
          className="p-8 grid grid-cols-1 md:grid-cols-2 gap-6"
        >
          <input
            name="name"
            placeholder="Product Name"
            onChange={handleChange}
            className="md:col-span-2 input-style"
          />

          <input
            name="price"
            placeholder="Price"
            onChange={handleChange}
            className="input-style"
          />

          <input
            name="ingredients"
            placeholder="One Pack Contains"
            onChange={handleChange}
            className="input-style"
          />

          <textarea
            name="description"
            rows={4}
            placeholder="Product Description"
            onChange={handleChange}
            className="md:col-span-2 input-style"
          />

          <button className="md:col-span-2 bg-[#FE702E] text-white py-4 rounded-2xl font-semibold">
            Save Product
          </button>
        </form>
      </div>
    </div>
  );
}

export default AddProduct;
