import React from "react";
import { useNavigate, useParams } from "react-router-dom";

function ProductDetails() {
  const navigate = useNavigate();
  const { id } = useParams(); // 👈 product id

  return (
    <div className="w-full min-h-screen bg-[#FFF8F4] px-4 md:px-10 py-8">
      <h1 className="text-2xl md:text-3xl font-bold mb-6">
        Product Details (ID: {id})
      </h1>

      <div className="max-w-3xl mx-auto bg-white rounded-3xl border border-orange-100 shadow-sm overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1604908177522-4327b9b2c0b6"
          className="w-full h-64 object-cover"
        />

        <div className="p-6">
          <h2 className="text-2xl font-bold text-gray-800">
            Mixed Dry Fruits
          </h2>

          <p className="text-[#FE702E] text-lg font-semibold mt-2">
            ₹2000
          </p>

          <div className="mt-4">
            <h3 className="font-semibold">One Pack Contains:</h3>
            <p className="text-gray-600 mt-1">
              Red Quinoa, Lime, Honey, Blueberries
            </p>
          </div>

          <p className="text-gray-600 mt-4">
            If you are looking for a new fruit salad to eat today, quinoa is the
            perfect brunch for you.
          </p>

          {/* Actions */}
          <div className="flex gap-4 mt-8">
            <button
              onClick={() => navigate("/add-product")}
              className="flex-1 bg-orange-100 text-[#FE702E] py-3 rounded-xl font-semibold"
            >
              Edit Product
            </button>

            <button className="flex-1 bg-red-100 text-red-600 py-3 rounded-xl font-semibold">
              Delete Product
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProductDetails;
