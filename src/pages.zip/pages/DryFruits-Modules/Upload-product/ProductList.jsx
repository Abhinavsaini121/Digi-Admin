import React, { useState } from "react";
import { Plus, X } from "lucide-react";
import AddProduct from "./AddProduct";

function ProductList() {
  const [showAddProduct, setShowAddProduct] = useState(false);

  const products = [
    {
      id: 1,
      name: "Mixed Dry Fruits",
      price: "₹2000",
      image:
        "https://images.unsplash.com/photo-1531627475453-547f4624bc6b?w=500",
    },
    {
      id: 2,
      name: "Premium Almonds",
      price: "₹1500",
      image:
        "https://images.unsplash.com/photo-1720276103203-0f8ed8666831?w=500",
    },
  ]; 

  return (
    <div className="w-full min-h-screen bg-[#FFF8F4] px-4 md:px-10 py-8">
      
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl md:text-3xl font-bold text-gray-800">
          Products
        </h1>

        <button
          onClick={() => setShowAddProduct(true)}
          className="flex items-center gap-2 bg-[#FE702E] hover:bg-orange-600 text-white px-5 py-3 rounded-xl font-semibold transition"
        >
          <Plus size={18} />
          Add New Product
        </button>
      </div>

      {/* Product Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map((product) => (
          <div
            key={product.id}
            className="bg-white rounded-3xl shadow-sm border border-orange-100 hover:shadow-md transition overflow-hidden"
          >
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-48 object-cover"
            />

            <div className="p-5">
              <h2 className="font-semibold text-lg text-gray-800">
                {product.name}
              </h2>
              <p className="text-[#FE702E] font-bold mt-1">
                {product.price}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* 🔥 ADD PRODUCT MODAL */}
      {showAddProduct && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="relative w-full max-w-5xl max-h-[90vh] overflow-y-auto bg-white rounded-3xl shadow-xl">
            
            {/* Close Button */}
            <button
              onClick={() => setShowAddProduct(false)}
              className="absolute top-4 right-4 bg-orange-100 hover:bg-orange-200 p-2 rounded-full"
            >
              <X size={18} />
            </button>

            <AddProduct />
          </div>
        </div>
      )}
    </div>
  );
}

export default ProductList;