import { useState } from "react";

const UserManagement = () => {
  const [search, setSearch] = useState("");

  const users = [
    {
      id: 101,
      name: "Rahul Sharma",
      email: "rahul@email.com",
      status: "ACTIVE",
    },
    {
      id: 102,
      name: "Anita Verma",
      email: "anita@email.com",
      status: "BLOCKED",
    },
  ];

  return (
    <div className="bg-orange-50 p-6">
      <div className="max-w-7xl mx-auto">

        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-orange-500">
            User Management
          </h2>

          <input
            type="text"
            placeholder="Search users..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="px-4 py-2 border-2 border-orange-400 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-300"
          />
        </div>

        {/* Table */}
        <div className="border-2 border-orange-400 rounded-xl overflow-hidden">
          <table className="w-full border-collapse">
            <thead className="bg-orange-50">
              <tr>
                <th className="px-4 py-3 text-left text-orange-500 font-semibold">ID</th>
                <th className="px-4 py-3 text-left text-orange-500 font-semibold">Name</th>
                <th className="px-4 py-3 text-left text-orange-500 font-semibold">Email</th>
                <th className="px-4 py-3 text-left text-orange-500 font-semibold">Status</th>
                <th className="px-4 py-3 text-left text-orange-500 font-semibold">Actions</th>
              </tr>
            </thead>

            <tbody className="divide-y bg-white divide-orange-200">
              {users
                .filter(
                  (u) =>
                    u.name.toLowerCase().includes(search.toLowerCase()) ||
                    u.email.toLowerCase().includes(search.toLowerCase())
                )
                .map((user) => (
                  <tr
                    key={user.id}
                    className="hover:bg-orange-50 transition"
                  >
                    <td className="px-4 py-3">{user.id}</td>
                    <td className="px-4 py-3">{user.name}</td>
                    <td className="px-4 py-3">{user.email}</td>

                    <td className="px-4 py-3">
                      {user.status === "ACTIVE" ? (
                        <span className="px-3 py-1 text-sm rounded-full bg-green-100 text-green-700 font-medium">
                          Active
                        </span>
                      ) : (
                        <span className="px-3 py-1 text-sm rounded-full bg-red-100 text-red-600 font-medium">
                          Blocked
                        </span>
                      )}
                    </td>

                    <td className="px-4 py-3 space-x-2">
                      <button className="px-3 py-1 border border-orange-400 text-orange-500 rounded-md hover:bg-orange-100">
                        View
                      </button>

                      {user.status === "ACTIVE" ? (
                        <button className="px-3 py-1 bg-orange-500 text-white rounded-md hover:bg-orange-600">
                          Block
                        </button>
                      ) : (
                        <button className="px-3 py-1 bg-green-600 text-white rounded-md hover:bg-green-700">
                          Unblock
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>

      </div>
    </div>
  );
};

export default UserManagement;
