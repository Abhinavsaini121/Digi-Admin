import { useNavigate } from "react-router-dom";

const WorkerList = () => {
  const navigate = useNavigate();

  const workers = [
    {
      id: 201,
      name: "Amit Kumar",
      email: "amit@worker.com",
      status: "ACTIVE",
    },
    {
      id: 202,
      name: "Priya Singh",
      email: "priya@worker.com",
      status: "INACTIVE",
    },
  ];

  return (
    <div className="bg-orange-50 p-6">
      <div className="max-w-7xl mx-auto">

        {/* Header */}
        <h2 className="text-2xl font-bold text-orange-500 mb-6">
          Workers List
        </h2>

        {/* Table */}
        <div className="border-2 border-orange-400 rounded-xl overflow-hidden">
          <table className="w-full">
            <thead className="bg-orange-50">
              <tr>
                <th className="px-4 py-3 text-left text-orange-500">ID</th>
                <th className="px-4 py-3 text-left text-orange-500">Name</th>
                <th className="px-4 py-3 text-left text-orange-500">Email</th>
                <th className="px-4 py-3 text-left text-orange-500">Status</th>
                <th className="px-4 py-3 text-left text-orange-500">Action</th>
              </tr>
            </thead>

            <tbody className="divide-y bg-white divide-orange-200">
              {workers.map((worker) => (
                <tr key={worker.id} className="hover:bg-orange-50">
                  <td className="px-4 py-3">{worker.id}</td>
                  <td className="px-4 py-3">{worker.name}</td>
                  <td className="px-4 py-3">{worker.email}</td>
                  <td className="px-4 py-3">
                    {worker.status === "ACTIVE" ? (
                      <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm">
                        Active
                      </span>
                    ) : (
                      <span className="px-3 py-1 bg-red-100 text-red-600 rounded-full text-sm">
                        Inactive
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <button
                      onClick={() => navigate(`/worker/manage/${worker.id}`)}
                      className="px-4 py-1 bg-orange-500 text-white rounded-md hover:bg-orange-600"
                    >
                      Manage
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

      </div>
    </div>
  );
};

export default WorkerList;
