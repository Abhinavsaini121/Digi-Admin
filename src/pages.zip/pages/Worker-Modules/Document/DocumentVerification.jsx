import React from "react";
import { Eye } from "lucide-react";
import { useNavigate } from "react-router-dom";

const DocumentVerification = () => {
  const navigate = useNavigate();

  // Dummy data (API later)
  const workers = [
    {
      id: 1,
      name: "Rohit Kumar",
      role: "Electrician",
      status: "Pending",
    },
    {
      id: 2,
      name: "Amit Sharma",
      role: "Plumber",
      status: "Verified",
    },
  ];

  return (
    <div className="w-full min-h-screen bg-[#FBF6FF] p-6">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-800">
          Document Verification
        </h1>
        <p className="text-sm text-gray-500">
          Review and verify worker documents
        </p>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl shadow-md border border-orange-100 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-orange-50">
            <tr>
              <th className="px-4 py-3 text-left">Worker Name</th>
              <th className="px-4 py-3 text-left">Role</th>
              <th className="px-4 py-3 text-center">Status</th>
              <th className="px-4 py-3 text-center">Action</th>
            </tr>
          </thead>

          <tbody>
            {workers.map((worker) => (
              <tr
                key={worker.id}
                className="border-t hover:bg-orange-50/40 transition"
              >
                <td className="px-4 py-3 font-medium">
                  {worker.name}
                </td>

                <td className="px-4 py-3">{worker.role}</td>

                <td className="px-4 py-3 text-center">
                  {worker.status === "Pending" ? (
                    <span className="px-3 py-1 rounded-full text-xs bg-yellow-100 text-yellow-700">
                      Pending
                    </span>
                  ) : (
                    <span className="px-3 py-1 rounded-full text-xs bg-green-100 text-green-700">
                      Verified
                    </span>
                  )}
                </td>

                <td className="px-4 py-3 text-center">
                  {worker.status === "Pending" && (
                    <button
                      onClick={() =>
                        navigate(`/documents/${worker.id}`)
                      }
                      className="inline-flex items-center gap-2 px-3 py-1.5
                      bg-orange-100 text-[#FE702E] rounded-lg
                      hover:bg-orange-200 transition"
                    >
                      <Eye className="w-4 h-4" />
                      View Documents
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default DocumentVerification;
