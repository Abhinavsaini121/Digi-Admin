import React from "react";
import { CheckCircle } from "lucide-react";

const ViewDocuments = () => {
  // Dummy documents
  const documents = [
    { id: 1, name: "Aadhar Card", file: "aadhar.jpg" },
    { id: 2, name: "PAN Card", file: "pan.jpg" },
    { id: 3, name: "Address Proof", file: "address.pdf" },
  ];

  return (
    <div className="w-full min-h-screen bg-[#FBF6FF] p-6">
      {/* Header */}
      <h1 className="text-2xl font-semibold text-gray-800 mb-6">
        Worker Documents
      </h1>

      {/* Documents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {documents.map((doc) => (
          <div
            key={doc.id}
            className="bg-white border border-orange-100
            rounded-xl shadow-sm p-4"
          >
            <p className="font-medium text-gray-700 mb-2">
              {doc.name}
            </p>

            <div className="h-40 bg-gray-100 rounded-lg
            flex items-center justify-center text-gray-400">
              Document Preview
            </div>

            <button
              className="mt-3 w-full py-2 rounded-lg
              bg-orange-100 text-[#FE702E]
              hover:bg-orange-200 transition"
            >
              View Full
            </button>
          </div>
        ))}
      </div>

      {/* Verify Button */}
      <div className="mt-10 flex justify-end">
        <button
          className="flex items-center gap-2 px-6 py-3
          bg-[#FE702E] text-white rounded-xl
          hover:opacity-90 transition"
        >
          <CheckCircle className="w-5 h-5" />
          Verify Documents
        </button>
      </div>
    </div>
  );
};

export default ViewDocuments;
