import React from "react";
import { CheckCircle, XCircle } from "lucide-react";

const ManageLeaves = () => {
  // TEMP dummy data (API later)
  const leaveRequests = [
    {
      id: 1,
      name: "Rohit Kumar",
      type: "Sick Leave",
      from: "2025-01-10",
      to: "2025-01-12",
      reason: "Fever and weakness",
      status: "Pending",
    },
    {
      id: 2,
      name: "Amit Sharma",
      type: "Casual Leave",
      from: "2025-01-15",
      to: "2025-01-15",
      reason: "Personal work",
      status: "Pending",
    },
  ];

  return (
    <div className="w-full min-h-screen bg-[#FBF6FF] p-6">
      {/* PAGE HEADER */}
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-800">
          Manage Leaves
        </h1>
        <p className="text-sm text-gray-500">
          Review and approve worker leave applications
        </p>
      </div>

      {/* TABLE CARD */}
      <div className="bg-white rounded-2xl shadow-md border border-orange-100 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-orange-50 text-gray-700">
            <tr>
              <th className="px-4 py-3 text-left">Worker Name</th>
              <th className="px-4 py-3 text-left">Leave Type</th>
              <th className="px-4 py-3">From</th>
              <th className="px-4 py-3">To</th>
              <th className="px-4 py-3 text-left">Reason</th>
              <th className="px-4 py-3 text-center">Status</th>
              <th className="px-4 py-3 text-center">Action</th>
            </tr>
          </thead>

          <tbody>
            {leaveRequests.map((leave) => (
              <tr
                key={leave.id}
                className="border-t hover:bg-orange-50/40 transition"
              >
                <td className="px-4 py-3 font-medium text-gray-800">
                  {leave.name}
                </td>

                <td className="px-4 py-3">{leave.type}</td>

                <td className="px-4 py-3 text-center">{leave.from}</td>

                <td className="px-4 py-3 text-center">{leave.to}</td>

                <td className="px-4 py-3">{leave.reason}</td>

                <td className="px-4 py-3 text-center">
                  <span className="px-3 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-700">
                    {leave.status}
                  </span>
                </td>

                <td className="px-4 py-3">
                  <div className="flex items-center justify-center gap-2">
                    <button
                      className="flex items-center gap-1 px-3 py-1.5
                      rounded-lg bg-green-100 text-green-700
                      hover:bg-green-200 transition"
                    >
                      <CheckCircle className="w-4 h-4" />
                      Accept
                    </button>

                    <button
                      className="flex items-center gap-1 px-3 py-1.5
                      rounded-lg bg-red-100 text-red-600
                      hover:bg-red-200 transition"
                    >
                      <XCircle className="w-4 h-4" />
                      Reject
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* EMPTY STATE (future use) */}
        {leaveRequests.length === 0 && (
          <div className="text-center py-10 text-gray-500">
            No leave applications found
          </div>
        )}
      </div>
    </div>
  );
};

export default ManageLeaves;
