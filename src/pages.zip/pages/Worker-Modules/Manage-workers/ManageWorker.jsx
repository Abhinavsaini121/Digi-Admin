import { useParams, useNavigate } from "react-router-dom";

const ManageWorker = () => {
  const { workerId } = useParams();
  const navigate = useNavigate();

  const options = [
    { name: "Document Verification", path: "/documents" },
    { name: "Manage Leave", path: "/hrms/leaves" },
    { name: "Location", path: "/location" },
    { name: "Worker Order", path: "worker-order" },
  ];

  return (
    <div className="bg-orange-50 p-6">
      <div className="max-w-6xl mx-auto">

        {/* Header */}
        <div className="flex items-center mb-6">
          <button
            onClick={() => navigate(-1)}
            className="mr-4 text-orange-500 hover:underline"
          >
            ← Back
          </button>

          <h2 className="text-2xl font-bold text-orange-500">
            Manage Worker (ID: {workerId})
          </h2>
        </div>

        {/* Options */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {options.map((opt, index) => (
            <div
              key={index}
              onClick={() =>
                navigate(`${opt.path}`)
              }
              className="border-2 border-orange-400 rounded-xl p-5 cursor-pointer hover:bg-orange-50 hover:shadow-md transition"
            >
              <h3 className="text-lg font-semibold text-orange-500 mb-2">
                {opt.name}
              </h3>
              <p className="text-gray-600 text-sm">
                Manage {opt.name.toLowerCase()}
              </p>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
};

export default ManageWorker;
