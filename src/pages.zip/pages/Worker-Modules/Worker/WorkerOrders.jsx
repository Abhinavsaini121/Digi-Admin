import React from 'react'

const WorkerOrders = () => {
  return (
    <div>
        <h1 className="text-2xl md:text-3xl font-bold text-gray-800 mb-6">Hello</h1>
    </div>
  )
}

export default WorkerOrders
